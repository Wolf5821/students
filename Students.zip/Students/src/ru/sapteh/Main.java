package ru.sapteh;

import ru.sapteh.model.Students;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class Main {
    public static void main(String[] args) throws IOException {
            ConnectionDB connectionDB = new ConnectionDB();
            Connection connection = connectionDB.getConnection();
            List<Students> listStudents = new ArrayList<>();

            try {
                String sql = "SELECT * FROM " + Students.TABLE_NAME;
                PreparedStatement statement = connection.prepareStatement(sql);
                ResultSet resultSet = statement.executeQuery();
                Students students = null;
                while (resultSet.next()) {
                    int id = resultSet.getInt(Students.COLUMN_ID);
                    String fio = resultSet.getString("FIO");
                    String dateRoshd = resultSet.getString("DateRoshd");
                    String specialnost = resultSet.getString("Specialnost");
                    String kyrs = resultSet.getString("Kyrs");
                    String grupa = resultSet.getString("Grupa");
                    students = new Students(id, fio, dateRoshd, specialnost,kyrs,grupa);
                    listStudents.add(students);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }


            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

            System.out.println("-s для выбора данных из таблицы по id");
            System.out.println("-i для добавление данных в таблицу");
            System.out.println("-u для обновления данных в таблице по id");
            System.out.println("-d для удаления данных из таблицы по id");


            String strReader = reader.readLine();
//        Select;
            if (strReader.equals("-s")) {
                System.out.print("Введите id:");
                strReader = reader.readLine();
                try {
                    String sqlSelect = "SELECT * FROM " + Students.TABLE_NAME + " WHERE id = ?";
                    PreparedStatement statement = connection.prepareStatement(sqlSelect);
                    statement.setInt(1, Integer.parseInt(strReader));
                    ResultSet resultSet = statement.executeQuery();
                    while (resultSet.next()) {
                        int id = resultSet.getInt("id");
                        String fio = resultSet.getString("FIO");
                        String dateRoshd = resultSet.getString("DateRoshd");
                        String specialnost = resultSet.getString("Specialnost");
                        String kyrs = resultSet.getString("Kyrs");
                        String grupa = resultSet.getString("Grupa");
                        Students students = new Students(id, fio, dateRoshd, specialnost,kyrs,grupa);
                        listStudents.add(students);
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if (strReader.equals("-i")) {
                System.out.println("Введите ФИО: ");
                String fio = reader.readLine();
                System.out.println("Введите дату рождения: ");
                String dateRoshd = reader.readLine();
                System.out.println("Специальность: ");
                String specialnost = reader.readLine();
                System.out.println("Курс: ");
                String course = reader.readLine();
                System.out.println("Группа: ");
                String group = reader.readLine();

                Students students = new Students(listStudents.size() + 1, fio, dateRoshd, specialnost,course,group);

                try {
                    String sqlInsert = "INSERT INTO " + Students.TABLE_NAME +"(FIO,DateRoshd,specialnost,Kyrs,grupa) VALUES (?,?,?,?,?)";
                    PreparedStatement statement = connection.prepareStatement(sqlInsert);
                    statement.setString(1, students.getFIO());
                    statement.setString(2, students.getDateRoshd());
                    statement.setString(3, students.getSpecialnost());
                    statement.setString(4, students.getKyrs());
                    statement.setString(5, students.getGrupa());
                    statement.executeUpdate();
                    listStudents.add(students);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if (strReader.equals("-u")) {
                System.out.println("Введите id: ");
                int id = Integer.parseInt(reader.readLine());
                System.out.println("Введите ФИО: ");
                String fio = reader.readLine();
                System.out.println("Введите дату рождения: ");
                String dateRoshd = reader.readLine();
                System.out.println("Специальность: ");
                String specialnost = reader.readLine();
                System.out.println("Курс: ");
                String course = reader.readLine();
                System.out.println("Группа: ");
                String group = reader.readLine();

                Students students = new Students(id, fio, dateRoshd, specialnost, course, group);

                try {
                    String sqlUpdate = "UPDATE " + Students.TABLE_NAME + " SET FIO=?, DateRoshd=?,specialnost=?,Kyrs=?,grupa=? WHERE id=?";
                    PreparedStatement statement = connection.prepareStatement(sqlUpdate);
                    statement.setString(1,students.getFIO() );
                    statement.setString(2,students.getDateRoshd() );
                    statement.setString(3,students.getSpecialnost() );
                    statement.setString(4,students.getKyrs() );
                    statement.setString(5,students.getGrupa());
                    statement.setInt(6, id);
                    statement.executeUpdate();
                    listStudents.add(students);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if (strReader.equals("-d")) {
                System.out.println("Введите id: ");
                int id = Integer.parseInt(reader.readLine());
                try {
                    String sqlUpdate = "DELETE FROM " + Students.TABLE_NAME + " WHERE id=?";
                    PreparedStatement statement = connection.prepareStatement(sqlUpdate);
                    statement.setInt(1, id);
                    statement.executeUpdate();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            for (Students students : listStudents) {
                System.out.println(students);
            }
        }
    }

