package ru.sapteh;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionDB {
    private static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
    private static final String URL_DB = "jdbc:mysql://localhost:3306/students?serverTimezone = UTC";
    private static final String LOGIN_DB = "root";
    private static final String PASSWORD_DB = "1234";
//    Connection;
    public Connection getConnection(){
        Connection connection = null;
        try {
            Class.forName(DB_DRIVER);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
            try {
                connection = DriverManager.getConnection(URL_DB,LOGIN_DB,PASSWORD_DB);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return connection;
    }
    public void closeConnection(Connection connection){
        if(connection == null) return;
        try {
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
