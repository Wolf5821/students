package ru.sapteh.model;

import java.util.Objects;

public class Students {
    public static final String TABLE_NAME = "students";
    public static final String COLUMN_ID = "id";
    public static final String FIO_COLUMN = "fio";
    public static final String GATEROSHD_COLUMN = "DateRoshd";
    public static final String SPECIALNOST_COLUMN = "specialnost";
    public static final String KYRS_COLUMN = "kyrs";
    public static final String GRUPA_COLUMN = "grupa";



    private int id;
    private String fio;
    private String dateRoshd;
    private String specialnost;
    private String kyrs;
    private String grupa;

    public Students(int id, String fio, String dateRoshd, String specialnost, String kyrs, String grupa){
        this.id = id;
        this.fio = fio;
        this.dateRoshd = dateRoshd;
        this.specialnost = specialnost;
        this.kyrs = kyrs;
        this.grupa = grupa;
    }

    public int getId() {
        return id;
    }

    public String getFIO() {
        return fio;
    }

    public String getDateRoshd() {
        return dateRoshd;
    }

    public String getSpecialnost() {
        return specialnost;
    }

    public String getKyrs() {
        return kyrs;
    }

    public String getGrupa() {
        return grupa;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setFIO(String FIO) {
        this.fio = FIO;
    }

    public void setDateRoshd(String dateRoshd) {
        dateRoshd = dateRoshd;
    }

    public void setSpecialnost(String specialnost) {
        specialnost = specialnost;
    }

    public void setKyrs(String kyrs) {
        kyrs = kyrs;
    }

    public void setGrupa(String grupa) {
        grupa = grupa;
    }
    @Override
    public String toString(){
        return String.format("%d %s %s %s %s %s", getId(), getFIO(), getDateRoshd(), getSpecialnost(), getKyrs(), getGrupa());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Students students = (Students) o;
        return id == students.id &&
                dateRoshd == students.dateRoshd &&
                kyrs == students.kyrs &&
                grupa == students.grupa &&
                Objects.equals(fio, students.fio) &&
                Objects.equals(specialnost, students.specialnost);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, fio, dateRoshd, specialnost, kyrs, grupa);
    }
}

